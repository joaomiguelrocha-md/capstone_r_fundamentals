# ineptR 0.2.1

* Added unit testing and codecov integration.
* Corrected some edge cases that might result in errors.

# ineptR 0.2.0

* Fixed issues to comply with the CRAN policy:
'Packages which use Internet resources should fail gracefully with an
informative message if the resource is not available or has changed (and
not give a check warning nor error).' (#2)

# ineptR 0.1.0

* First release.
